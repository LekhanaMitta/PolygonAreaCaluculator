module AreaCaluculator {
    requires java.desktop;
}
